terminate called after throwing an instance of 'PLMD::Plumed::Exception'
  what():  
Action "PYFUNCTION" is not known.
[pkrvmbietmlfzoi:35163] *** Process received signal ***
[pkrvmbietmlfzoi:35163] Signal: Aborted (6)
[pkrvmbietmlfzoi:35163] Signal code:  (-6)
[pkrvmbietmlfzoi:35163] [ 0] /lib/x86_64-linux-gnu/libc.so.6(+0x45330)[0x7fa912045330]
[pkrvmbietmlfzoi:35163] [ 1] /lib/x86_64-linux-gnu/libc.so.6(pthread_kill+0x11c)[0x7fa91209eb2c]
[pkrvmbietmlfzoi:35163] [ 2] /lib/x86_64-linux-gnu/libc.so.6(gsignal+0x1e)[0x7fa91204527e]
[pkrvmbietmlfzoi:35163] [ 3] /lib/x86_64-linux-gnu/libc.so.6(abort+0xdf)[0x7fa9120288ff]
[pkrvmbietmlfzoi:35163] [ 4] /lib/x86_64-linux-gnu/libstdc++.so.6(+0xa5ff5)[0x7fa9124a5ff5]
[pkrvmbietmlfzoi:35163] [ 5] /lib/x86_64-linux-gnu/libstdc++.so.6(+0xbb0da)[0x7fa9124bb0da]
[pkrvmbietmlfzoi:35163] [ 6] /lib/x86_64-linux-gnu/libstdc++.so.6(_ZSt10unexpectedv+0x0)[0x7fa9124a5a55]
[pkrvmbietmlfzoi:35163] [ 7] /lib/x86_64-linux-gnu/libstdc++.so.6(+0xa5a6f)[0x7fa9124a5a6f]
[pkrvmbietmlfzoi:35163] [ 8] plumed_master(+0x146dd)[0x55a9cda366dd]
[pkrvmbietmlfzoi:35163] [ 9] /lib/x86_64-linux-gnu/libc.so.6(+0x2a1ca)[0x7fa91202a1ca]
[pkrvmbietmlfzoi:35163] [10] /lib/x86_64-linux-gnu/libc.so.6(__libc_start_main+0x8b)[0x7fa91202a28b]
[pkrvmbietmlfzoi:35163] [11] plumed_master(+0x15365)[0x55a9cda37365]
[pkrvmbietmlfzoi:35163] *** End of error message ***
