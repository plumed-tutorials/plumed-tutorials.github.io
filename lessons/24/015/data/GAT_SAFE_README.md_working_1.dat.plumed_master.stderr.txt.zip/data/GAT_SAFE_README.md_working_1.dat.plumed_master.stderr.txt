terminate called after throwing an instance of 'PLMD::Plumed::Exception'
  what():  
Action "PYCVINTERFACE" is not known.
[pkrvmf6wy0o8zjz:58777] *** Process received signal ***
[pkrvmf6wy0o8zjz:58777] Signal: Aborted (6)
[pkrvmf6wy0o8zjz:58777] Signal code:  (-6)
[pkrvmf6wy0o8zjz:58777] [ 0] /lib/x86_64-linux-gnu/libc.so.6(+0x45330)[0x7f2831045330]
[pkrvmf6wy0o8zjz:58777] [ 1] /lib/x86_64-linux-gnu/libc.so.6(pthread_kill+0x11c)[0x7f283109eb2c]
[pkrvmf6wy0o8zjz:58777] [ 2] /lib/x86_64-linux-gnu/libc.so.6(gsignal+0x1e)[0x7f283104527e]
[pkrvmf6wy0o8zjz:58777] [ 3] /lib/x86_64-linux-gnu/libc.so.6(abort+0xdf)[0x7f28310288ff]
[pkrvmf6wy0o8zjz:58777] [ 4] /lib/x86_64-linux-gnu/libstdc++.so.6(+0xa5ff5)[0x7f28314a5ff5]
[pkrvmf6wy0o8zjz:58777] [ 5] /lib/x86_64-linux-gnu/libstdc++.so.6(+0xbb0da)[0x7f28314bb0da]
[pkrvmf6wy0o8zjz:58777] [ 6] /lib/x86_64-linux-gnu/libstdc++.so.6(_ZSt10unexpectedv+0x0)[0x7f28314a5a55]
[pkrvmf6wy0o8zjz:58777] [ 7] /lib/x86_64-linux-gnu/libstdc++.so.6(+0xa5a6f)[0x7f28314a5a6f]
[pkrvmf6wy0o8zjz:58777] [ 8] plumed_master(+0x146dd)[0x5576dafff6dd]
[pkrvmf6wy0o8zjz:58777] [ 9] /lib/x86_64-linux-gnu/libc.so.6(+0x2a1ca)[0x7f283102a1ca]
[pkrvmf6wy0o8zjz:58777] [10] /lib/x86_64-linux-gnu/libc.so.6(__libc_start_main+0x8b)[0x7f283102a28b]
[pkrvmf6wy0o8zjz:58777] [11] plumed_master(+0x15365)[0x5576db000365]
[pkrvmf6wy0o8zjz:58777] *** End of error message ***
