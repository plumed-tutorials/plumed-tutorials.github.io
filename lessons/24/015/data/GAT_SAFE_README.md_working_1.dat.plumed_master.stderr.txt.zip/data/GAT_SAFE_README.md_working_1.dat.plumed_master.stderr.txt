terminate called after throwing an instance of 'PLMD::Plumed::Exception'
  what():  
Action "PYCVINTERFACE" is not known.
[runnervm3jyl0:46573] *** Process received signal ***
[runnervm3jyl0:46573] Signal: Aborted (6)
[runnervm3jyl0:46573] Signal code:  (-6)
[runnervm3jyl0:46573] [ 0] /lib/x86_64-linux-gnu/libc.so.6(+0x45330)[0x7ff0f5245330]
[runnervm3jyl0:46573] [ 1] /lib/x86_64-linux-gnu/libc.so.6(pthread_kill+0x11c)[0x7ff0f529eb2c]
[runnervm3jyl0:46573] [ 2] /lib/x86_64-linux-gnu/libc.so.6(gsignal+0x1e)[0x7ff0f524527e]
[runnervm3jyl0:46573] [ 3] /lib/x86_64-linux-gnu/libc.so.6(abort+0xdf)[0x7ff0f52288ff]
[runnervm3jyl0:46573] [ 4] /lib/x86_64-linux-gnu/libstdc++.so.6(+0xa5ff5)[0x7ff0f56a5ff5]
[runnervm3jyl0:46573] [ 5] /lib/x86_64-linux-gnu/libstdc++.so.6(+0xbb0da)[0x7ff0f56bb0da]
[runnervm3jyl0:46573] [ 6] /lib/x86_64-linux-gnu/libstdc++.so.6(_ZSt10unexpectedv+0x0)[0x7ff0f56a5a55]
[runnervm3jyl0:46573] [ 7] /lib/x86_64-linux-gnu/libstdc++.so.6(+0xa5a6f)[0x7ff0f56a5a6f]
[runnervm3jyl0:46573] [ 8] plumed_master(+0x146dd)[0x55cc71d8e6dd]
[runnervm3jyl0:46573] [ 9] /lib/x86_64-linux-gnu/libc.so.6(+0x2a1ca)[0x7ff0f522a1ca]
[runnervm3jyl0:46573] [10] /lib/x86_64-linux-gnu/libc.so.6(__libc_start_main+0x8b)[0x7ff0f522a28b]
[runnervm3jyl0:46573] [11] plumed_master(+0x15365)[0x55cc71d8f365]
[runnervm3jyl0:46573] *** End of error message ***
