terminate called after throwing an instance of 'PLMD::Plumed::Exception'
  what():  
Action "PYCVINTERFACE" is not known.
[pkrvmbietmlfzoi:35118] *** Process received signal ***
[pkrvmbietmlfzoi:35118] Signal: Aborted (6)
[pkrvmbietmlfzoi:35118] Signal code:  (-6)
[pkrvmbietmlfzoi:35118] [ 0] /lib/x86_64-linux-gnu/libc.so.6(+0x45330)[0x7fa8ab045330]
[pkrvmbietmlfzoi:35118] [ 1] /lib/x86_64-linux-gnu/libc.so.6(pthread_kill+0x11c)[0x7fa8ab09eb2c]
[pkrvmbietmlfzoi:35118] [ 2] /lib/x86_64-linux-gnu/libc.so.6(gsignal+0x1e)[0x7fa8ab04527e]
[pkrvmbietmlfzoi:35118] [ 3] /lib/x86_64-linux-gnu/libc.so.6(abort+0xdf)[0x7fa8ab0288ff]
[pkrvmbietmlfzoi:35118] [ 4] /lib/x86_64-linux-gnu/libstdc++.so.6(+0xa5ff5)[0x7fa8ab4a5ff5]
[pkrvmbietmlfzoi:35118] [ 5] /lib/x86_64-linux-gnu/libstdc++.so.6(+0xbb0da)[0x7fa8ab4bb0da]
[pkrvmbietmlfzoi:35118] [ 6] /lib/x86_64-linux-gnu/libstdc++.so.6(_ZSt10unexpectedv+0x0)[0x7fa8ab4a5a55]
[pkrvmbietmlfzoi:35118] [ 7] /lib/x86_64-linux-gnu/libstdc++.so.6(+0xa5a6f)[0x7fa8ab4a5a6f]
[pkrvmbietmlfzoi:35118] [ 8] plumed_master(+0x146dd)[0x55e6c6c886dd]
[pkrvmbietmlfzoi:35118] [ 9] /lib/x86_64-linux-gnu/libc.so.6(+0x2a1ca)[0x7fa8ab02a1ca]
[pkrvmbietmlfzoi:35118] [10] /lib/x86_64-linux-gnu/libc.so.6(__libc_start_main+0x8b)[0x7fa8ab02a28b]
[pkrvmbietmlfzoi:35118] [11] plumed_master(+0x15365)[0x55e6c6c89365]
[pkrvmbietmlfzoi:35118] *** End of error message ***
