PLUMED: PLUMED is starting
PLUMED: Version: 2.9.2 (git: 4a575f47c) compiled on Dec  7 2024 at 13:53:13
PLUMED: Please cite these papers when using PLUMED [1][2]
PLUMED: For further information see the PLUMED web page at http://www.plumed.org
PLUMED: Root: /home/runner/opt/lib/plumed
PLUMED: For installed feature, see /home/runner/opt/lib/plumed/src/config/config.txt
PLUMED: Molecular dynamics engine: driver
PLUMED: Precision of reals: 8
PLUMED: Running over 1 node
PLUMED: Number of threads: 1
PLUMED: Cache line size: 512
PLUMED: Number of atoms: 100000
PLUMED: File suffix: 
PLUMED: FILE: GAT_SAFE_README.md_working_1.dat
PLUMED: ERROR
PLUMED: I cannot understand line: PYCVINTERFACE LABEL=cvPY ATOMS=1,4 IMPORT=pydistancePBCs CALCULATE=pydist
PLUMED: Maybe a missing space or a typo?
PLUMED: ################################################################################
PLUMED: 
PLUMED: (core/PlumedMain.cpp:824) void PLMD::PlumedMain::readInputWords(const std::vector<std::__cxx11::basic_string<char> >&)
PLUMED: ERROR
PLUMED: I cannot understand line: PYCVINTERFACE LABEL=cvPY ATOMS=1,4 IMPORT=pydistancePBCs CALCULATE=pydist
PLUMED: Maybe a missing space or a typo?
PLUMED: ################################################################################
