terminate called after throwing an instance of 'PLMD::Plumed::ExceptionError'
  what():  
(core/PlumedMain.cpp:903) void PLMD::PlumedMain::readInputWords(const std::vector<std::__cxx11::basic_string<char> >&)
ERROR
I cannot understand line: PYFUNCTION LABEL=fPY IMPORT=pycvfunc CALCULATE=plumedCalculate ARG=d1,d2
Maybe a missing space or a typo?
[fv-az1279-640:05378] *** Process received signal ***
[fv-az1279-640:05378] Signal: Aborted (6)
[fv-az1279-640:05378] Signal code:  (-6)
[fv-az1279-640:05378] [ 0] /lib/x86_64-linux-gnu/libc.so.6(+0x45330)[0x7f7e33045330]
[fv-az1279-640:05378] [ 1] /lib/x86_64-linux-gnu/libc.so.6(pthread_kill+0x11c)[0x7f7e3309eb2c]
[fv-az1279-640:05378] [ 2] /lib/x86_64-linux-gnu/libc.so.6(gsignal+0x1e)[0x7f7e3304527e]
[fv-az1279-640:05378] [ 3] /lib/x86_64-linux-gnu/libc.so.6(abort+0xdf)[0x7f7e330288ff]
[fv-az1279-640:05378] [ 4] /lib/x86_64-linux-gnu/libstdc++.so.6(+0xa5ff5)[0x7f7e334a5ff5]
[fv-az1279-640:05378] [ 5] /lib/x86_64-linux-gnu/libstdc++.so.6(+0xbb0da)[0x7f7e334bb0da]
[fv-az1279-640:05378] [ 6] /lib/x86_64-linux-gnu/libstdc++.so.6(_ZSt10unexpectedv+0x0)[0x7f7e334a5a55]
[fv-az1279-640:05378] [ 7] /lib/x86_64-linux-gnu/libstdc++.so.6(+0xa5a6f)[0x7f7e334a5a6f]
[fv-az1279-640:05378] [ 8] plumed(+0x13209)[0x561ceaa02209]
[fv-az1279-640:05378] [ 9] /lib/x86_64-linux-gnu/libc.so.6(+0x2a1ca)[0x7f7e3302a1ca]
[fv-az1279-640:05378] [10] /lib/x86_64-linux-gnu/libc.so.6(__libc_start_main+0x8b)[0x7f7e3302a28b]
[fv-az1279-640:05378] [11] plumed(+0x134a5)[0x561ceaa024a5]
[fv-az1279-640:05378] *** End of error message ***
