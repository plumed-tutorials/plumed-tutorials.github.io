terminate called after throwing an instance of 'PLMD::Plumed::ExceptionError'
  what():  
(core/PlumedMain.cpp:903) void PLMD::PlumedMain::readInputWords(const std::vector<std::__cxx11::basic_string<char> >&)
ERROR
I cannot understand line: PYFUNCTION LABEL=fPY IMPORT=pycvfunc CALCULATE=plumedCalculate ARG=d1,d2
Maybe a missing space or a typo?
[pkrvmf6wy0o8zjz:58850] *** Process received signal ***
[pkrvmf6wy0o8zjz:58850] Signal: Aborted (6)
[pkrvmf6wy0o8zjz:58850] Signal code:  (-6)
[pkrvmf6wy0o8zjz:58850] [ 0] /lib/x86_64-linux-gnu/libc.so.6(+0x45330)[0x7fd21e845330]
[pkrvmf6wy0o8zjz:58850] [ 1] /lib/x86_64-linux-gnu/libc.so.6(pthread_kill+0x11c)[0x7fd21e89eb2c]
[pkrvmf6wy0o8zjz:58850] [ 2] /lib/x86_64-linux-gnu/libc.so.6(gsignal+0x1e)[0x7fd21e84527e]
[pkrvmf6wy0o8zjz:58850] [ 3] /lib/x86_64-linux-gnu/libc.so.6(abort+0xdf)[0x7fd21e8288ff]
[pkrvmf6wy0o8zjz:58850] [ 4] /lib/x86_64-linux-gnu/libstdc++.so.6(+0xa5ff5)[0x7fd21eca5ff5]
[pkrvmf6wy0o8zjz:58850] [ 5] /lib/x86_64-linux-gnu/libstdc++.so.6(+0xbb0da)[0x7fd21ecbb0da]
[pkrvmf6wy0o8zjz:58850] [ 6] /lib/x86_64-linux-gnu/libstdc++.so.6(_ZSt10unexpectedv+0x0)[0x7fd21eca5a55]
[pkrvmf6wy0o8zjz:58850] [ 7] /lib/x86_64-linux-gnu/libstdc++.so.6(+0xa5a6f)[0x7fd21eca5a6f]
[pkrvmf6wy0o8zjz:58850] [ 8] plumed(+0x13209)[0x55ede04ee209]
[pkrvmf6wy0o8zjz:58850] [ 9] /lib/x86_64-linux-gnu/libc.so.6(+0x2a1ca)[0x7fd21e82a1ca]
[pkrvmf6wy0o8zjz:58850] [10] /lib/x86_64-linux-gnu/libc.so.6(__libc_start_main+0x8b)[0x7fd21e82a28b]
[pkrvmf6wy0o8zjz:58850] [11] plumed(+0x134a5)[0x55ede04ee4a5]
[pkrvmf6wy0o8zjz:58850] *** End of error message ***
