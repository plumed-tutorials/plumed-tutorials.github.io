terminate called after throwing an instance of 'PLMD::Plumed::ExceptionError'
  what():  
(core/PlumedMain.cpp:903) void PLMD::PlumedMain::readInputWords(const std::vector<std::__cxx11::basic_string<char> >&)
ERROR
I cannot understand line: PYFUNCTION LABEL=fPY IMPORT=pycvfunc CALCULATE=plumedCalculate ARG=d1,d2
Maybe a missing space or a typo?
[pkrvmf6wy0o8zjz:58812] *** Process received signal ***
[pkrvmf6wy0o8zjz:58812] Signal: Aborted (6)
[pkrvmf6wy0o8zjz:58812] Signal code:  (-6)
[pkrvmf6wy0o8zjz:58812] [ 0] /lib/x86_64-linux-gnu/libc.so.6(+0x45330)[0x7fa08e845330]
[pkrvmf6wy0o8zjz:58812] [ 1] /lib/x86_64-linux-gnu/libc.so.6(pthread_kill+0x11c)[0x7fa08e89eb2c]
[pkrvmf6wy0o8zjz:58812] [ 2] /lib/x86_64-linux-gnu/libc.so.6(gsignal+0x1e)[0x7fa08e84527e]
[pkrvmf6wy0o8zjz:58812] [ 3] /lib/x86_64-linux-gnu/libc.so.6(abort+0xdf)[0x7fa08e8288ff]
[pkrvmf6wy0o8zjz:58812] [ 4] /lib/x86_64-linux-gnu/libstdc++.so.6(+0xa5ff5)[0x7fa08eca5ff5]
[pkrvmf6wy0o8zjz:58812] [ 5] /lib/x86_64-linux-gnu/libstdc++.so.6(+0xbb0da)[0x7fa08ecbb0da]
[pkrvmf6wy0o8zjz:58812] [ 6] /lib/x86_64-linux-gnu/libstdc++.so.6(_ZSt10unexpectedv+0x0)[0x7fa08eca5a55]
[pkrvmf6wy0o8zjz:58812] [ 7] /lib/x86_64-linux-gnu/libstdc++.so.6(+0xa5a6f)[0x7fa08eca5a6f]
[pkrvmf6wy0o8zjz:58812] [ 8] plumed(+0x13209)[0x556880590209]
[pkrvmf6wy0o8zjz:58812] [ 9] /lib/x86_64-linux-gnu/libc.so.6(+0x2a1ca)[0x7fa08e82a1ca]
[pkrvmf6wy0o8zjz:58812] [10] /lib/x86_64-linux-gnu/libc.so.6(__libc_start_main+0x8b)[0x7fa08e82a28b]
[pkrvmf6wy0o8zjz:58812] [11] plumed(+0x134a5)[0x5568805904a5]
[pkrvmf6wy0o8zjz:58812] *** End of error message ***
