terminate called after throwing an instance of 'PLMD::Plumed::ExceptionError'
  what():  
(core/PlumedMain.cpp:903) void PLMD::PlumedMain::readInputWords(const std::vector<std::__cxx11::basic_string<char> >&)
ERROR
I cannot understand line: PYCVINTERFACE LABEL=cv1 ATOMS=@mdatoms IMPORT=pycvPersistentData CALCULATE=pydist INIT=pyinit
Maybe a missing space or a typo?
[runnervm3jyl0:79440] *** Process received signal ***
[runnervm3jyl0:79440] Signal: Aborted (6)
[runnervm3jyl0:79440] Signal code:  (-6)
[runnervm3jyl0:79440] [ 0] /lib/x86_64-linux-gnu/libc.so.6(+0x45330)[0x7f926e045330]
[runnervm3jyl0:79440] [ 1] /lib/x86_64-linux-gnu/libc.so.6(pthread_kill+0x11c)[0x7f926e09eb2c]
[runnervm3jyl0:79440] [ 2] /lib/x86_64-linux-gnu/libc.so.6(gsignal+0x1e)[0x7f926e04527e]
[runnervm3jyl0:79440] [ 3] /lib/x86_64-linux-gnu/libc.so.6(abort+0xdf)[0x7f926e0288ff]
[runnervm3jyl0:79440] [ 4] /lib/x86_64-linux-gnu/libstdc++.so.6(+0xa5ff5)[0x7f926e4a5ff5]
[runnervm3jyl0:79440] [ 5] /lib/x86_64-linux-gnu/libstdc++.so.6(+0xbb0da)[0x7f926e4bb0da]
[runnervm3jyl0:79440] [ 6] /lib/x86_64-linux-gnu/libstdc++.so.6(_ZSt10unexpectedv+0x0)[0x7f926e4a5a55]
[runnervm3jyl0:79440] [ 7] /lib/x86_64-linux-gnu/libstdc++.so.6(+0xa5a6f)[0x7f926e4a5a6f]
[runnervm3jyl0:79440] [ 8] plumed(+0x13209)[0x55f0a1bc6209]
[runnervm3jyl0:79440] [ 9] /lib/x86_64-linux-gnu/libc.so.6(+0x2a1ca)[0x7f926e02a1ca]
[runnervm3jyl0:79440] [10] /lib/x86_64-linux-gnu/libc.so.6(__libc_start_main+0x8b)[0x7f926e02a28b]
[runnervm3jyl0:79440] [11] plumed(+0x134a5)[0x55f0a1bc64a5]
[runnervm3jyl0:79440] *** End of error message ***
