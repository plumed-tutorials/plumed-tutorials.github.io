terminate called after throwing an instance of 'PLMD::Plumed::ExceptionError'
  what():  
(core/PlumedMain.cpp:903) void PLMD::PlumedMain::readInputWords(const std::vector<std::__cxx11::basic_string<char> >&)
ERROR
I cannot understand line: PYCVINTERFACE LABEL=cv1 ATOMS=@mdatoms IMPORT=pycvPersistentData CALCULATE=pydist INIT=pyinit
Maybe a missing space or a typo?
[pkrvmf6wy0o8zjz:58858] *** Process received signal ***
[pkrvmf6wy0o8zjz:58858] Signal: Aborted (6)
[pkrvmf6wy0o8zjz:58858] Signal code:  (-6)
[pkrvmf6wy0o8zjz:58858] [ 0] /lib/x86_64-linux-gnu/libc.so.6(+0x45330)[0x7f818e045330]
[pkrvmf6wy0o8zjz:58858] [ 1] /lib/x86_64-linux-gnu/libc.so.6(pthread_kill+0x11c)[0x7f818e09eb2c]
[pkrvmf6wy0o8zjz:58858] [ 2] /lib/x86_64-linux-gnu/libc.so.6(gsignal+0x1e)[0x7f818e04527e]
[pkrvmf6wy0o8zjz:58858] [ 3] /lib/x86_64-linux-gnu/libc.so.6(abort+0xdf)[0x7f818e0288ff]
[pkrvmf6wy0o8zjz:58858] [ 4] /lib/x86_64-linux-gnu/libstdc++.so.6(+0xa5ff5)[0x7f818e4a5ff5]
[pkrvmf6wy0o8zjz:58858] [ 5] /lib/x86_64-linux-gnu/libstdc++.so.6(+0xbb0da)[0x7f818e4bb0da]
[pkrvmf6wy0o8zjz:58858] [ 6] /lib/x86_64-linux-gnu/libstdc++.so.6(_ZSt10unexpectedv+0x0)[0x7f818e4a5a55]
[pkrvmf6wy0o8zjz:58858] [ 7] /lib/x86_64-linux-gnu/libstdc++.so.6(+0xa5a6f)[0x7f818e4a5a6f]
[pkrvmf6wy0o8zjz:58858] [ 8] plumed(+0x13209)[0x55d61ca55209]
[pkrvmf6wy0o8zjz:58858] [ 9] /lib/x86_64-linux-gnu/libc.so.6(+0x2a1ca)[0x7f818e02a1ca]
[pkrvmf6wy0o8zjz:58858] [10] /lib/x86_64-linux-gnu/libc.so.6(__libc_start_main+0x8b)[0x7f818e02a28b]
[pkrvmf6wy0o8zjz:58858] [11] plumed(+0x134a5)[0x55d61ca554a5]
[pkrvmf6wy0o8zjz:58858] *** End of error message ***
