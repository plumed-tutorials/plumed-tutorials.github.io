terminate called after throwing an instance of 'PLMD::Plumed::Exception'
  what():  
Action "PYCVINTERFACE" is not known.
[runnervm3jyl0:46663] *** Process received signal ***
[runnervm3jyl0:46663] Signal: Aborted (6)
[runnervm3jyl0:46663] Signal code:  (-6)
[runnervm3jyl0:46663] [ 0] /lib/x86_64-linux-gnu/libc.so.6(+0x45330)[0x7fc325645330]
[runnervm3jyl0:46663] [ 1] /lib/x86_64-linux-gnu/libc.so.6(pthread_kill+0x11c)[0x7fc32569eb2c]
[runnervm3jyl0:46663] [ 2] /lib/x86_64-linux-gnu/libc.so.6(gsignal+0x1e)[0x7fc32564527e]
[runnervm3jyl0:46663] [ 3] /lib/x86_64-linux-gnu/libc.so.6(abort+0xdf)[0x7fc3256288ff]
[runnervm3jyl0:46663] [ 4] /lib/x86_64-linux-gnu/libstdc++.so.6(+0xa5ff5)[0x7fc325aa5ff5]
[runnervm3jyl0:46663] [ 5] /lib/x86_64-linux-gnu/libstdc++.so.6(+0xbb0da)[0x7fc325abb0da]
[runnervm3jyl0:46663] [ 6] /lib/x86_64-linux-gnu/libstdc++.so.6(_ZSt10unexpectedv+0x0)[0x7fc325aa5a55]
[runnervm3jyl0:46663] [ 7] /lib/x86_64-linux-gnu/libstdc++.so.6(+0xa5a6f)[0x7fc325aa5a6f]
[runnervm3jyl0:46663] [ 8] plumed_master(+0x146dd)[0x55ba193b46dd]
[runnervm3jyl0:46663] [ 9] /lib/x86_64-linux-gnu/libc.so.6(+0x2a1ca)[0x7fc32562a1ca]
[runnervm3jyl0:46663] [10] /lib/x86_64-linux-gnu/libc.so.6(__libc_start_main+0x8b)[0x7fc32562a28b]
[runnervm3jyl0:46663] [11] plumed_master(+0x15365)[0x55ba193b5365]
[runnervm3jyl0:46663] *** End of error message ***
