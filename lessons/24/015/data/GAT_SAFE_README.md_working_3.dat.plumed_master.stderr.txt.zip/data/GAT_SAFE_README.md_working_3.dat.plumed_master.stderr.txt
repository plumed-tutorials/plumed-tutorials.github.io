terminate called after throwing an instance of 'PLMD::Plumed::Exception'
  what():  
Action "PYCVINTERFACE" is not known.
[pkrvmbietmlfzoi:35208] *** Process received signal ***
[pkrvmbietmlfzoi:35208] Signal: Aborted (6)
[pkrvmbietmlfzoi:35208] Signal code:  (-6)
[pkrvmbietmlfzoi:35208] [ 0] /lib/x86_64-linux-gnu/libc.so.6(+0x45330)[0x7fa2f0a45330]
[pkrvmbietmlfzoi:35208] [ 1] /lib/x86_64-linux-gnu/libc.so.6(pthread_kill+0x11c)[0x7fa2f0a9eb2c]
[pkrvmbietmlfzoi:35208] [ 2] /lib/x86_64-linux-gnu/libc.so.6(gsignal+0x1e)[0x7fa2f0a4527e]
[pkrvmbietmlfzoi:35208] [ 3] /lib/x86_64-linux-gnu/libc.so.6(abort+0xdf)[0x7fa2f0a288ff]
[pkrvmbietmlfzoi:35208] [ 4] /lib/x86_64-linux-gnu/libstdc++.so.6(+0xa5ff5)[0x7fa2f0ea5ff5]
[pkrvmbietmlfzoi:35208] [ 5] /lib/x86_64-linux-gnu/libstdc++.so.6(+0xbb0da)[0x7fa2f0ebb0da]
[pkrvmbietmlfzoi:35208] [ 6] /lib/x86_64-linux-gnu/libstdc++.so.6(_ZSt10unexpectedv+0x0)[0x7fa2f0ea5a55]
[pkrvmbietmlfzoi:35208] [ 7] /lib/x86_64-linux-gnu/libstdc++.so.6(+0xa5a6f)[0x7fa2f0ea5a6f]
[pkrvmbietmlfzoi:35208] [ 8] plumed_master(+0x146dd)[0x562b9a7e16dd]
[pkrvmbietmlfzoi:35208] [ 9] /lib/x86_64-linux-gnu/libc.so.6(+0x2a1ca)[0x7fa2f0a2a1ca]
[pkrvmbietmlfzoi:35208] [10] /lib/x86_64-linux-gnu/libc.so.6(__libc_start_main+0x8b)[0x7fa2f0a2a28b]
[pkrvmbietmlfzoi:35208] [11] plumed_master(+0x15365)[0x562b9a7e2365]
[pkrvmbietmlfzoi:35208] *** End of error message ***
