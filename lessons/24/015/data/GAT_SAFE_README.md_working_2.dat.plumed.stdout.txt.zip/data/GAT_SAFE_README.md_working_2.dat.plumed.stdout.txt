PLUMED: PLUMED is starting
PLUMED: Version: 2.9.4 (git: fc56f8054) compiled on Jun 25 2025 at 14:52:46
PLUMED: Please cite these papers when using PLUMED [1][2]
PLUMED: For further information see the PLUMED web page at http://www.plumed.org
PLUMED: Root: /home/runner/opt/lib/plumed
PLUMED: For installed feature, see /home/runner/opt/lib/plumed/src/config/config.txt
PLUMED: Molecular dynamics engine: driver
PLUMED: Precision of reals: 8
PLUMED: Running over 1 node
PLUMED: Number of threads: 1
PLUMED: Cache line size: 512
PLUMED: Number of atoms: 100000
PLUMED: File suffix: 
PLUMED: FILE: GAT_SAFE_README.md_working_2.dat
PLUMED: Action DISTANCE
PLUMED:   with label d1
PLUMED:   between atoms 1 2
PLUMED:   using periodic boundary conditions
PLUMED: Action DISTANCE
PLUMED:   with label d2
PLUMED:   between atoms 1 3
PLUMED:   using periodic boundary conditions
PLUMED: ERROR
PLUMED: I cannot understand line: PYFUNCTION LABEL=fPY IMPORT=pycvfunc CALCULATE=plumedCalculate ARG=d1,d2
PLUMED: Maybe a missing space or a typo?
PLUMED: ################################################################################
PLUMED: 
PLUMED: (core/PlumedMain.cpp:903) void PLMD::PlumedMain::readInputWords(const std::vector<std::__cxx11::basic_string<char> >&)
PLUMED: ERROR
PLUMED: I cannot understand line: PYFUNCTION LABEL=fPY IMPORT=pycvfunc CALCULATE=plumedCalculate ARG=d1,d2
PLUMED: Maybe a missing space or a typo?
PLUMED: ################################################################################
